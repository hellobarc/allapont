Cursors Created By: http://blog.ruphy.org/
Downloaded At: http://www.cursors-4u.com/

--------------------------
Instructions
---------------------------
Right Click the .ini file (notepad lookalike file) and choose install
Then go to Control Panel
Then "Mouse"
Click on the "Pointers" tab in the dialog box that pops
Under "Scheme" locate the cursor scheme called "Oxy xxxx" xxxx would probably be the color theme name.

----------
FAQ
----------
Who wrote these instructions?
A: Cursors-4U.com Admin did.

What does the .ini file do?
A: It copys the cursors file in the current folder and moves them to c:drive > windows > Cursors.  You can verify this yourself by going to the directory.  After it's done copying the files, you can delete the source cursors.

Does it contain viruses?
A: No, you can verify by scanning the files with a scanner. 

Can I support the Author?
A: Yes you can.  Go to their website and donate to them or just leave a nice comment or two.